
public class Inventory {
	
	int iD;
	int qnt;
	int loc;
	double wt;
	
	public Inventory(int iD, int quantity, int location, double weight) {
		this.iD = iD;
		this.qnt = quantity;
		this.loc = location;
		this.wt = weight;
	}
	
	public void printInventory() {
		System.out.println("\nID Number: "+ iD + "\nNumber in stock: " + qnt + "\nLocation in warehouse: Sector " + loc + "\nWeight: " + wt + "kg");
	}
	
	public void addStock(int num) {
		this.qnt += num;
	}
	
	public void removeStock(int num) {
		this.qnt -= num;
	}
	
	//consider combining the ArrayList into Inventory class

}
