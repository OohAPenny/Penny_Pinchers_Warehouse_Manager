import java.util.*;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * Something with ID numbers, warehouse locations, 
 * quantity, and weight, with a way to 
 * sort by each of these values?
 */

/*
 * ArrayList has yet to be written, I am not sure yet 
 * whether to combine it into the Inventory class or to 
 * include it within the main class
 */

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		int iD; // 10 digit SKU
		int sector; /*
					 *this will be held in an integer value (1-8) for 
					 *organization reasons
					 */
		double weight; //held as a value of Kilograms
		int quantity; // will be renamed for brevity
		int selection = 0; /*
		 					* variable for the purpose of choosing 
		 					* options in the navigation menu, will 
		 					* be renamed for brevity
		 					*/
		
		System.out.println("Welcome to the Penny Warehouse Manager�!\nPlease make a selection:\n");
		System.out.println("1. Add item\n2. Remove item\n3. Find item\n4. Modify item\n5. Print Inventory");
		if(selection == 1) {
			// code section is dependent on ArrayList that has not been written
		} else if(selection == 2) {
			// code section is dependent on ArrayList that has not been written
		} else if(selection == 3) {
			// code section is dependent on ArrayList that has not been written, this segment will specifically access parts of the Inventory Obj
		} else if(selection == 4) {
			// code section is dependent on both an ArrayList and object class that has not been written
		} else if(selection == 5) {
			// code section is incomplete as it depends on an object class that has not been written
			File file = new File ("C:\\Users\\gabe2\\Desktop\\JavaStuff\\output.txt");
			try {
				boolean fileExists = file.createNewFile();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			PrintWriter p = null;
			try {
				p = new PrintWriter(file);
				p.println("");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			p.close();
		}

	}

}
